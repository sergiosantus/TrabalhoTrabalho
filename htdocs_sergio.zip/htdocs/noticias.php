<?php

// Configuração inicial da página
require ('_config.php');

// Define o título "desta" página
$titulo = "Notícias";

// Opção ativa no menu principal
$menu = "noticias";

// Aponta para o CSS "desta" página. Ex.: /css/contatos.css
// Deixe vazio para não usar CSS adicional nesta página
$css = "/css/noticias.css";

// Aponta para o JavaScript "desta" página. Ex.: /js/contatos.js
// Deixe vazio para não usar JavaScript adicional nesta página
$js = "";

/*********************************************/
/*  SEUS CÓDIGOS PHP DESTA PÁGINA FICAM AQUI */
/*********************************************/

// 'Declarar' variáveis
$noticias = '';      // Armazena a view de artigos
$titulopagina = $titulo;     // Armazena a view de categorias

// Ler o Id da categoria


    // Obtendo ids de todos os artigos
    $sql = <<<SQL

SELECT id_not FROM noticias
    WHERE status_not = 'ativo'
        AND data_not <= NOW()
    ORDER BY data_not DESC;

SQL;
    $res = $conn->query($sql);
    
    
    

    // Cria subtítulo com total de artigos
    

    // Título da página
    

    // Obtendo o nome
   

// Obtendo os nomes das categorias


// Obtendo cada registro
while ( $art = $res->fetch_assoc() ):

    // Listando os artigos em "$artigos" usando a função
    $noticias .= viewnoticia( $art['id_not'] );

endwhile;


/************************************************/
/*  SEUS CÓDIGOS PHP DESTA PÁGINA TERMINAM AQUI */
/************************************************/

// Inclui o cabeçalho do template
require ('_header.php');

?>

<div class="row">
    <div class="col1">

        <h2><?php echo $titulopagina ?></h2>
        
        <?php echo $noticias ?>

    </div>
    
</div>

<?php

// Inclui o rodapé do template
require ('_footer.php');

// Função que gera a view de um artigo
function viewnoticia($id) {

    // Obtém a variável $conn do escopo global
    global $conn;

    // Obtendo artigo do banco de dados
    $sql = <<<SQL

SELECT id_not, titulo, manchete
FROM noticias
WHERE id_not = '{$id}'
    AND status_not = 'ativo'
    AND data_not <= NOW()
;

SQL;
    $res = $conn->query($sql);

    // Se achou o artigo
    if ( $res->num_rows == 1 ):

        // Gerar a view do artigo
        $art = $res->fetch_assoc();
        

        $noticia = <<<TEXTO

<div class="noticia">
    <a href="/noticia.php?id={$art['id_not']}">
        <h3>{$art['titulo']}</h3>
    </a>
    <span>{$art['manchete']}</span>
    <br/>
    <br/>
    <hr/>
</div>

TEXTO;




        // Retorna com o artigo pronto
        return $noticia;

    // Se o artigo não existe ou é inválido
    else:

        // Retorna com false;
        return false;

    endif;

} 


?>