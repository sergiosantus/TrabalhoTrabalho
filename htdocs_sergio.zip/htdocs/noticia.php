<?php

// Configuração inicial da página
require ('_config.php');

// Define o título "desta" página
$titulo = "Notícia";

// Opção ativa no menu principal
// Valores possíveis: "", "artigos", "noticias", "contatos", "sobre", "procurar"
// Valores diferentes destes = ""
$menu = "noticias";

// Aponta para o CSS "desta" página. Ex.: /css/contatos.css
// Deixe vazio para não usar CSS adicional nesta página
$css = "/css/noticias.css";

// Aponta para o JavaScript "desta" página. Ex.: /js/contatos.js
// Deixe vazio para não usar JavaScript adicional nesta página
$js = "";

/*********************************************/
/*  SEUS CÓDIGOS PHP DESTA PÁGINA FICAM AQUI */
/*********************************************/

// Ler o id do artigo da URL
$id = ( isset($_GET['id']) ) ? intval($_GET['id']) : 0;

// Se não pediu um artigo (id não informado)
if ( $id == 0 ) header('Location: noticias.php');

// Pesquisando artigo no banco de dados
$sql = <<<SQL

SELECT id_not, titulo, texto_not,
        DATE_FORMAT(data_not, '%d/%m/%Y às %H:%i') AS databr
    FROM noticias
    INNER JOIN autores ON autor_id = id_autor
WHERE
    id_not = '{$id}'
    AND status_not = 'ativo'
    AND data_not <= NOW()
;

SQL;

    // Executar a query
    $res = $conn->query($sql);

    // Se o artigo não exite
    if ( $res->num_rows != 1 ) header('Location: noticias.php');

    // Obtendo campos do artigo
    $art = $res->fetch_assoc();

    // View do artigo
    $noticia = <<<TEXTO

    <h2>{$art['titulo']}</h2>
    <hr/>
    <p class="totalart">
        
    </p>
    {$art['texto_not']}
    
TEXTO;
// Obtendo as categorias deste artigo

// Executando a query

// Listando cada categoria
// SQL da lista de recomendados

// Atualizando artigo com as categorias

    // View da lista de recomendados
    // Loop da lista de recomendados
   

        // Executa a query que obtém o artigo
        $resart = $conn->query($sql);

        // Obtem os campos do artigo
        $artrec = $resart->fetch_assoc();

        // Gerando o view
        

  

  


// Calcular idade do autor

// Modal com dados do autor


/************************************************/
/*  SEUS CÓDIGOS PHP DESTA PÁGINA TERMINAM AQUI */
/************************************************/

// Inclui o cabeçalho do template
require ('_header.php');

?>

<?php echo $noticia ?>


<?php

// Inclui o rodapé do template
require ('_footer.php');

?>
