<?php

// Tratamento do título da página
if ($titulo == "") {
    $titulo = "Sem Nome - O melhor de todos.";
} else {
    $titulo = "{$titulo} - Notícias Brasil";
}

// Tratamento do CSS da página
if ($css != "") {
    $css = "<link rel=\"stylesheet\" href=\"{$css}\">\n";
} else {
    $css = null;
}

// Tratamento do JavaScript da página --> _footer.php
if ($js != "") {
    $js = "<script src=\"{$js}\"></script>\n";
} else {
    $js = null;
}

?><!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $titulo ?></title>
    <link rel="shortcut icon" href="/img/logo03.png">
    <link rel="stylesheet" href="/css/global.css">
    <link rel="stylesheet" href="/css/all.min.css">
    <?php echo $css ?>
</head>
<body>
<a id="topo"></a>

<div class="wrap">

    <header class="header">
        <a href="#" title="Sem Nome - O melhor de todos"><img src="img/logo03.png" alt="Sem Nome"></a>
        <h1>Agri Brasil<small>Sempre no ar.</small></h1>   
    </header>

    <nav class="nav">
        <a href="/"><i class="fas fa-fw fa-home"></i></a>
        <div id="menulinks">
            <a <?php echo ( $menu == 'artigos' ) ? 'class="active"' : null ?> href="/artigos.php"><i class="fas fa-fw fa-pen-nib"></i> Artigos</a>
            <a <?php echo ( $menu == 'noticias' ) ? 'class="active"' : null ?> href="/noticias.php"><i class="fas fa-fw fa-newspaper"></i> Notícias</a>
            <a <?php echo ( $menu == 'contatos' ) ? 'class="active"' : null ?> href="/contatos.php"><i class="fas fa-fw fa-mail-bulk"></i> Contatos</a>
            <a <?php echo ( $menu == 'sobre' ) ? 'class="active"' : null ?> href="/sobre.php"><i class="fas fa-fw fa-info-circle"></i> Sobre</a>

            <button id="pesquisa" onclick="document.getElementById('id02').style.display='block'"><i class="fas fa-fw fa-search"></i></button>
            <div id="id02" class="modal">
            <span onclick="document.getElementById('id02').style.display='none'"
                class="close" title="Close Modal">&times;</span>
                <form class="modal-content animate" action="#">

                    <div class="container">
                        <label for="search"><b>O que está procurando?</b></label>
                        <input type="text" placeholder="" name="search">
                    </div>
                </form>
            </div>

            <button onclick="document.getElementById('id01').style.display='block'">Login</button>
            <div id="id01" class="modal">
                <span onclick="document.getElementById('id01').style.display='none'"
                class="close" title="Close Modal">&times;</span>
                <form class="modal-content animate" action="/action_page.php">

                    <div class="container">
                        <label for="uname"><b>Nome de usuário</b></label>
                        <input type="text" placeholder="" name="uname" required>

                        <label for="psw"><b>Senha</b></label>
                        <input type="password" placeholder="" name="psw" required>

                        <button type="button">Login</button>
                        <label>
                            <input type="checkbox" checked="checked" name="remember"> Lembrar meus dados
                        </label>
                        </div>

                        <div class="container" style="background-color:#f1f1f1">
                        <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancelar</button>
                       
                        <span class="psw"><a href="#">Esqueci minha senha</a></span>
                        <span class="cadastro"><a href="/cadastro.php">Cadastre-se</a></span>
                    </div>
                    
                </form>
                </div>	
            
        </div>

        




        <a href="#menu" id="menu"><i class="fas fa-fw fa-bars"></i></a>
    </nav>

    <main class="main">
<!-- CONTEÚDO DA PÁGINA -->
        
        
