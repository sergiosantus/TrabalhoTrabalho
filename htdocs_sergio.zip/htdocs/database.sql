-- Banco de Dados da Aplicação "Sem Nome"
-- CUIDADO! ALTAMENTE DESTRUTIVO
-- Apague este arquivo quando a modelagem estiver concluída!

-- Apagando o banco de dados caso ele já exista 
DROP DATABASE IF EXISTS semnome;  
 
-- Criando o banco de dados em UTF-8 e com buscas case-insensitive
CREATE DATABASE semnome CHARACTER SET utf8 COLLATE utf8_general_ci;  

-- Selecionando o banco de dados
USE semnome;

-- Criando a tabela "contatos"
CREATE TABLE contatos (
    id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- "AAAA-MM-DD hh:mm:ss"
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    assunto VARCHAR(255) NOT NULL,
    mensagem TEXT,
    campo1 TEXT COMMENT 'Para uso futuro',
    campo2 TEXT COMMENT 'Para uso futuro',
    status ENUM('recebido', 'lido', 'respondido', 'apagado') DEFAULT 'recebido'
);

-- Criando a tabela "autores"
CREATE TABLE autores (
    id_autor INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    data_autor TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    thumb_autor VARCHAR(255) COMMENT 'Uma imagem que representa o autor',
    nome_autor VARCHAR(255) COMMENT 'Nome completo que só aparece nos detalhes',
    nome_tela VARCHAR(127) NOT NULL COMMENT 'Nome curto que aparece no site',
    email VARCHAR(255) NOT NULL,
    site VARCHAR(255) COMMENT 'Sites começam com http://',
    curriculo TEXT COMMENT 'Um mini-currículo do autor.',
    telefone VARCHAR(128),
    nascimento DATE COMMENT 'Formato: AAAA-MM-DD',
    campo1 TEXT COMMENT 'Para uso futuro',
    campo2 TEXT COMMENT 'Para uso futuro',
    campo3 TEXT COMMENT 'Para uso futuro',
    status_autor ENUM('inativo', 'ativo') DEFAULT 'ativo'
);

-- Criando a tabela "categorias"
CREATE TABLE categorias (
    id_categoria INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    categoria VARCHAR(63) NOT NULL,
    campo1 TEXT COMMENT 'Para uso futuro'
);

-- Criando a tabela "artigos"
CREATE TABLE artigos (
    id_artigo INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    data_artigo TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Pode ser uma data no futuro',
    thumb_artigo VARCHAR(255) COMMENT 'Uma imagem pequena que representa o artigo',
    titulo VARCHAR(255) NOT NULL,
    resumo VARCHAR(255),
    texto LONGTEXT COMMENT 'Pode usar HTML e CSS',
    autor_id INT NOT NULL COMMENT 'Chave estrangeira',
    campo1 TEXT COMMENT 'Para uso futuro',
    campo2 TEXT COMMENT 'Para uso futuro',
    campo3 TEXT COMMENT 'Para uso futuro',
    status_artigo ENUM('inativo', 'ativo') DEFAULT 'ativo',
    FOREIGN KEY (autor_id) REFERENCES autores (id_autor)
);

-- Criando a tabela "art_cat"
CREATE TABLE art_cat (
    id_art_cat INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    artigo_id INT NOT NULL COMMENT 'Chave estrangeira',
    categoria_id INT NOT NULL COMMENT 'Chave estrangeira',
    FOREIGN KEY (artigo_id) REFERENCES artigos (id_artigo),
    FOREIGN KEY (categoria_id) REFERENCES categorias (id_categoria)
);

-- Inserindo dados em "autores"
-- ou
-- Populando a tabela "autores"
INSERT INTO autores
    (
        thumb_autor, nome_autor,
        nome_tela, email,
        site, curriculo,
        telefone, nascimento
    )
VALUES
    (
        'https://picsum.photos/200', 'Joca da Silva',
        'Joca Silva', 'joca@silva.com',
        'http://www.jocasilva.com/', 'Programador desde os 5 anos de idade, quando fez seu primeiro programa para MSX.',
        '(21) 98765-4321', '1980-12-22'
    ),
    (
        'https://picsum.photos/200', 'Dilermano dos Santos Soares',
        'Diler Soares', 'diler@mano.com',
        'http://mano.com/', 'Escrevedor de códigos desde a época do CP-500. Programa desde que sofreu um acidente e ficou de castigo.',
        '(21) 99887-7665', '1974-04-14'
    ),
    (
        'https://picsum.photos/200', 'Marineuza Sirinelson da Costa',
        'Mari Siri', 'mari@neuza.com.br',
        'http://mari.neuza.com.br/', 'Mecânica de computadores, formada pela faculdade de ciências ocultas da curva do vento, comecou na carreira após seu PC ser afogado nas chuvas do Rio de Janeiro.',
        '(21) 98988-9988', '1999-09-09'
    )
;

-- Populando a tabela "categorias"
INSERT INTO categorias (categoria) VALUES
('Alta'), 
('Agricultura'),
('Pecuária')
;
-- Populando a tabela "artigos"
INSERT INTO artigos (
    data_artigo,
    thumb_artigo,
    titulo,
    resumo,
    texto,
    autor_id
) VALUES 
(
    '2020-02-03 11:44:00',
    'https://picsum.photos/201',
    'Femagri: bom momento do café deixa setor otimista para investimentos',
    'Os cooperados da Cooxupé, maior cooperativa de café do mundo, já comercializaram 40% da próxima safra do grão',
    '<p>O surto do novo coronavírus provocou o fechamento de mais de 2 mil cafeterias na China nos últimos meses, gerando apreensão na demanda pelo café brasileiro. Por outro lado, outros países da Ásia estão compensando esta perda.<br/>
        Com a valorização do preço do café, os produtores estão mais animados em aumentar os investimentos. Os cooperados da Cooxupé, maior cooperativa de café do mundo,  já comercializaram 40% da próxima safra do grão, em um cenário que deixa os produtores animados, já que em 2019 o preço estava 25% menor do que é registrado agora, quando a saca é vendida por cerca de R$ 530.<br/>
        Direto da Femagri, realizada em Guaxupé, o repórter Antônio Pétrin mostras as novidades que devem movimentar o setor nos próximos meses. </p>',
    '1'
),
(
    '2020-02-05 08:12:27',
    'https://picsum.photos/202',
    'Arroz: condição das estradas preocupa produtores gaúchos',
    'Já os problemas com armazenagem podem ter sido resolvidos pela redução de área plantada na safra 2019/2020',
    '<p>A colheita do arroz, no Sul, deve se intensificar no início de março. Produtores estão preocupados com as condições das estradas, que podem dificultar a logística da safra. “Temos muitos problemas e não só nas estradas asfaltadas, como também nas do interior, que dependemos muito”, afirma o presidente da Federação das Associações de Arrozeiros do Rio Grande do Sul (Federarroz), Alexandre Velho.<br/>
    Com a redução na área plantada, o problema de armazenagem está solucionado e vai sobrar até espaço. Mesmo assim, o trabalho das entidades para que os produtores tenham seus próprios armazéns continua. O objetivo é livrar os preços da pressão na época da colheita. “Quando você tem armazenagem própria, acaba tendo outro poder de barganha na hora da venda. Você coloca para a indústria somente o que tem necessidade de vender ou o que está compromissado com ela”, diz Alexandre Velho. </p>',
    '3'
),
(
    '2020-02-05 14:30:00',
    'https://picsum.photos/199',
    'Preço do boi fica estável com pasto em boa condição e pouca oferta',
    'As escalas de abate dos frigoríficos de menor porte seguem apertadas e o pecuarista tem mais poder de negociação',
    '<p>O mercado físico do boi gordo segue com preços firmes principais regiões de produção e comercialização do Brasil. O analista de Safras & Mercado, Fernando Henrique Iglesias, as escalas de abate dos frigoríficos de menor porte seguem apertadas. “Enquanto isso, a oferta de animais terminados, de forma geral, ainda é pequena, ainda mais com os pastos em boas condições e os pecuaristas retendo o gado no campo”, assinalou Iglesias.<br/>
    Segundo ele, há chances de alteração na dinâmica do mercado na segunda metade de fevereiro diante da tradicional desaceleração no consumo de carne bovina de final de mês.<br/>
    Em São Paulo, Capital, os preços do mercado à vista permanecem em R$ 204 a arroba. Em Minas Gerais, preços em R$ 195 a arroba, com alta diária de um real. Em Mato Grosso do Sul, os preços subiram R$ 191 a R$ 192 para R$ 192 a arroba, em Dourados. Em Goiás, o preço indicado ficou em R$ 192, em Goiânia, estável. Já em Cuiabá,  Mato Grosso, o preço permaneceu em R$ 179 em Cuiabá. </p>',
    '2'
),
(
    '2020-02-05 14:31:00',
    'https://picsum.photos/198',
    'Dólar cai após cinco recordes consecutivos; veja cotação',
    'O recuo da moeda no mercado doméstico refletiu a atuação do Banco Central (BC) no qual fez uma operação de venda de dólares',
    '<p>O dólar comercial fechou em queda de 0,45% no mercado à vista, cotado a R$ 4,332 para venda, interrompendo cinco pregões seguidos de alta e quatro fechamentos consecutivos de máximas históricas. O recuo da moeda no mercado doméstico refletiu a atuação do Banco Central (BC) no qual fez uma operação “surpresa” de swap cambial tradicional – equivalente a venda de dólares no mercado futuro após a moeda abrir o pregão na máxima histórica a R$ 4,383, quando a moeda renovou recorde no intraday. <br/>
    O diretor de mesa de câmbio de uma corretora nacional destaca que após o aviso do BC, às 10 horas, a moeda entrou em leilão voltando a operar abaixo da casa dos R$ 4,35 e passou a registrar mínimas sucessivas (a R$ 4,31). </p>',
    '1'
),
(
    '2020-02-11 18:25:00',
    'https://picsum.photos/200',
    '‘Dólar em alta gera imprevisibilidade para o mercado’, diz economista',
    'De acordo com o economista Roberto Padovani, a oscilação do câmbio é o que realmente deveria preocupar os mercados',
    '<p>O  dólar chegou nesta quinta-feira, 13, ao patamar de R$ 4,38 e,  para conter a alta, o Banco Central anunciou um leilão de R$ 1 bilhão de contratos ligados ao câmbio. Após a medida, a moeda caiu para R$ 4,32. De acordo com o economista Roberto Padovani, a oscilação do câmbio é o que realmente deveria preocupar os mercados, pois gera imprevisibilidade.<br/>
    Devido aos conflitos geopolíticos, o medo da desaceleração global e eleições norte- americanas, o dólar demonstra segurança, enfraquecendo o real. O ambiente conturbado e ruídos também influenciam a compra do dólar. “Esse é o momento para travar o campo. Para o exportador, o nível do dólar é um nível favorável, mas a minha sensação é que, ao longo do ano, principalmente no segundo semestre, o dólar tende a cair e isso gera ao exportador uma oportunidade”, disse.</p>',
    '3'
);

-- Populando a tabela "art_cat"
INSERT INTO art_cat
    (artigo_id, categoria_id)
VALUES
    (1, 1),
    (1, 2),
    (1, 2),
    (2, 1),
    (2, 3),
    (2, 3),
    (3, 1),
    (3, 1),
    (3, 2),
    (4, 1),
    (4, 3),
    (5, 3)
;

CREATE TABLE cadastro (
    id INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    login VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    cpf VARCHAR(255) NOT NULL,
    senha VARCHAR(255) NOT NULL,
    campo1 TEXT COMMENT 'extra',
    campo2 TEXT COMMENT 'extra',
    status ENUM('cadastrado', 'deletado') DEFAULT 'cadastrado'
);

CREATE TABLE noticias (
  id_not INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
  data_not timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  titulo varchar(255) DEFAULT NULL,
  manchete varchar(255) DEFAULT NULL COMMENT ' resumo da notícia',
  texto_not longtext COMMENT 'texto da noticia',
  autor_id int(11) NOT NULL COMMENT 'Chave estrangeira',
  fonte_not varchar(255) DEFAULT NULL COMMENT 'fonte da noticia',
  campo1 text COMMENT 'Para uso futuro',
  campo2 text COMMENT 'Para uso futuro',
  campo3 text COMMENT 'Para uso futuro',
  status_not enum('inativo','ativo') DEFAULT 'ativo'
);

INSERT INTO noticias(data_not,titulo,manchete,texto_not,autor_id,fonte_not) -- 6 campos
VALUES
('2020-02-02 10:44:00','Técnicos agrícolas podem ser prestadores de assistência técnica e extensão rural','Conselho Monetário Nacional aprovou medida para viabilizar operações baseadas no sistema nacional de crédito rural'
,'A Lei nº 13.639, de 26/3/2018, criou o Conselho Federal dos Técnicos Industriais, o Conselho Federal dos Técnicos Agrícolas, os Conselhos Regionais dos Técnicos Industriais e os Conselhos Regionais dos Técnicos Agrícolas, desvinculando esses profissionais dos Conselhos Regionais de Engenharia, Arquitetura e Agronomia (CREAs).<br/>Diante disso, para que os técnicos agrícolas não fiquem impedidos de prestar assistência aos produtores que queiram tomar recursos no sistema nacional de crédito rural e, dessa forma, essas operações não sejam inviabilizadas, com reflexos negativos para a safra em curso, o Conselho Monetário Nacional (CMN) aprovou alterações no Manual de Crédito Rural (MCR) para mencionar o Conselho Federal ou Regional de Técnicos Agrícolas entre os conselhos cujos filiados estão habilitados a prestar esse serviço.',
'1','Wikipedia'),


('2020-02-02 11:44:00','Recursos do pré-custeio permitem que produtores se planejem melhor, diz ministra','Banco do Brasil anunciou hoje a liberação de R$ 15 bilhões para a compra antecipada de insumos'
,'O Ministério da Agricultura, Pecuária e Abastecimento (Mapa) vai receber até o dia 6 de abril sugestões para a revisão do Sistema Nacional de Sementes e Mudas (SNSM). Foi publicada nessa quarta-feira (19), a Portaria 42  que submete à consulta pública pelo prazo de 45 dias as normas do Sistema Nacional de Sementes e Mudas.<br/>Os recursos serão disponibilizados para a compra antecipada de insumos e serão destinados aos clientes produtores rurais para financiamento das lavouras de soja, milho, algodão, café, arroz a cana-de-açúcar. As operações poderão ser contratadas com recursos controlados com taxas a partir de 6% ao ano e, alternativamente, com recursos não controlados (Letra de Crédito do Agronegócio) com taxas a partir de 6,1% ao ano.',
'2','Enciclopedia'),


('2020-02-09 11:44:00','Consulta pública fará revisão das normas do Sistema Nacional de Sementes e Mudas',' Sugestões podem ser enviadas ao Ministério da Agricultura até 6 de abril '
,'O Ministério da Agricultura, Pecuária e Abastecimento (Mapa) vai receber até o dia 6 de abril sugestões para a revisão do Sistema Nacional de Sementes e Mudas (SNSM). Foi publicada nessa quarta-feira (19), a Portaria 42  que submete à consulta pública pelo prazo de 45 dias as normas do Sistema Nacional de Sementes e Mudas<br/>O decreto 5.153 de 2004 será revisto, para simplificar os procedimentos relativos à produção de sementes e mudas e atividades posteriores, tais como o beneficiamento, a embalagem, o armazenamento, a análise, o comércio, a importação e a exportação.<br/>O anúncio foi feito após a primeira reunião do conselho do PPI, presidida pelo ministro da Economia, Paulo Guedes, e contou com as presenças do presidente da República, Jair Bolsonaro, da ministra da Agricultura, Pecuária e Abastecimento, Tereza Cristina, e do diretor-geral do Serviço Florestal Brasileiro, Valdir Colatto.',
'3','Internet'),


('2020-02-13 11:44:00','Governo Federal inclui concessão florestal no portfólio de prioridades do PPI',' O Programa de Parcerias de Investimentos vai transferir para a inciativa privada o manejo sustentável das florestas nacionais de Humaitá, Iquiri e Castanho '
,'O governo anunciou nesta quarta-feira (19), no Palácio do Planalto, a inclusão da concessão florestal no portfólio de 22 projetos do Programa de Parcerias de Investimentos (PPI). A resolução inédita vai permitir o manejo sustentável das florestas nacionais de Humaitá, Iquiri e Castanho, todas no estado do Amazonas .<br/>Após concedido o registro, o estabelecimento produtor de bebidas será fiscalizado de acordo com os critérios de risco estabelecidos para a sua atividade. Dependendo das condições e histórico do estabelecimento e do tipo de produto elaborado, a periodicidade de fiscalizações será estabelecida. O estabelecimento desses critérios de risco é essencial para otimizar as ações e a utilização de recursos pela fiscalização de bebidas, de forma a atender às demandas de 5.695 estabelecimentos produtores de bebidas espalhados pelas 27 unidades da Federação. ',
'1','Wikipedia'),


('2020-02-13 11:44:00','RETIFICAÇÃO: Análises mostram a contaminação de 53 lotes de cervejas da Backer','Na nota publicada nessa terça-feira (18), foram repetidos dois lotes da cerveja Belorizontina, produzida pela empresa Backer. Desta forma, são 53 lotes contaminados por monoetilenoglicol e/ou dietilenoglicol, segundo análises feitas pelo Laboratório Federal de Defesa Agropecuária (LFDA/MG), vinculado ao Ministério da Agricultura, Pecuária e Abastecimento (Mapa).',
'A fiscalização federal agropecuária, desempenhada pelo Ministério da Agricultura, Pecuária e Abastecimento (Mapa) em cervejarias e demais indústrias de bebidas, tem por objetivo verificar as condições tecnológicas e higiênico-sanitárias dos estabelecimentos produtores. O processo de regularização de uma empresa junto ao Mapa inicia-se com a concessão do registro do estabelecimento, o que o habilita a funcionar e comercializar seus produtos. Durante o processo de registro são solicitados documentos comprobatórios da habilitação para o funcionamento da empresa e é realizada vistoria prévia com o objetivo de verificar as instalações e os possíveis riscos apresentados pelas atividades ali desempenhadas.<br/>O projeto, que visa melhorar condições de vida de agricultores familiares do semiárido brasileiro, é desenvolvido pelo Mapa, através da Secretaria de Agricultura Familiar e Cooperativismo (SAF), em conjunto com a Agência Nacional de Assistência Técnica e Extensão Rural (Anater) e várias instituições que prestam serviços de assistência técnica e extensão rural (Ater), por meio de um acordo de empréstimo firmado entre o Brasil e o Fida. ',
'1','Wikipedia'),


('2020-02-02 10:44:00','Missão internacional destaca avanços de projeto coordenado pelo Mapa',' O projeto Dom Helder Câmara visa melhorar condições de vida de agricultores familiares do semiárido brasileiro ',
'Uma missão de apoio do Fundo Internacional de Desenvolvimento Agrícola (Fida) das Nações Unidas destacou os avanços do Projeto Dom Helder Câmara (PDHC) e o alto compromisso dos gestores do Ministério da Agricultura, Pecuária e Abastecimento (Mapa) com a sua implementação. A missão, realizada durante os dias 10 e 14 de fevereiro, teve como objetivos fortalecer e otimizar as atividades desenvolvidas pelo PDHC e avaliar a execução das ações em andamento.<br/>Atualmente, o Ministério mantem 502 negociações voltadas à exportação de produtos de origem animal e vegetal, envolvendo 129 países e organizações internacionais. Em 2019, 26 missões internacionais, de 14 países, vieram ao Brasil. Para dar andamento a estes acordos comerciais anualmente o Mapa emite 7 mil documentos. ',
'2','Wikipedia')
