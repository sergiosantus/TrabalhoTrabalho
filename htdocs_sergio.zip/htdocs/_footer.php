 

<!-- O CONTEÚDO DA PÁGINA TERMINA AQUI -->

</main>

<footer class="footer">
    <a href="/" title="Página inicial"><i class="fas fa-fw fa-home"></i></a>
    <div>
        <span title="&copy; Copyright 2020 Sergio Santos"><i class="far fa-copyright"></i> 2020 Sergio Santos</span title="&copy; Copyright 2020 André Luferat">
        <div>
            <a href="/contatos.php">Contatos</a>
            &nbsp;&bull;&nbsp;
            <a href="/privacidade.php">Privacidade</a>                    
        </div>
    </div>
    <a href="#topo" title="Topo da página"><i class="fas fa-fw fa-arrow-alt-circle-up"></i></a>
</footer>

</div>

<script src="/js/jquery.min.js"></script>
<script src="/js/global.js"></script>
<?php echo $js ?>    
</body>
</html>